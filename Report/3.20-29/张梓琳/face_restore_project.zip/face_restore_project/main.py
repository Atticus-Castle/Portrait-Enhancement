from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse
import torch
import cv2
import numpy as np
from PIL import Image
import os

app = FastAPI(title="AI 人像真实修复")
os.makedirs("results", exist_ok=True)

# ======================
# 真正的 AI 修复模型
# ======================
model_path = "models/codeformer-1.0.pth"

try:
    import basicsr
    from basicsr.archs.codeformer_arch import CodeFormer

    net = CodeFormer(
        dim_embd=512,
        codebook_size=1024,
        n_head=8,
        n_layers=9,
        connect_list=['32', '64', '128', '256'],
    )
    checkpoint = torch.load(model_path, map_location="cpu")
    if "params_ema" in checkpoint:
        checkpoint = checkpoint["params_ema"]
    net.load_state_dict(checkpoint)
    net.eval()
    AI_READY = True
except:
    AI_READY = False

# ======================
# 上传图片 → AI 修复
# ======================
@app.post("/restore")
async def restore_image(file: UploadFile = File(...)):
    img = Image.open(file.file).convert("RGB")
    img = np.array(img)[:, :, ::-1]  # 转成 OpenCV 格式

    if AI_READY:
        # 真正 AI 修复
        h, w = img.shape[:2]
        img = cv2.resize(img, (512, 512))
        img = img / 255.0
        img_t = torch.from_numpy(img).permute(2, 0, 1).float().unsqueeze(0)

        with torch.no_grad():
            output = net(img_t, w=0.5)[0].detach().cpu().squeeze()
        output = output.permute(1, 2, 0).numpy()
        output = (output * 255.0).clip(0, 255).astype(np.uint8)
        output = cv2.resize(output, (w, h))
    else:
        output = img

    save_path = "results/fixed_face.jpg"
    cv2.imwrite(save_path, output)

    return FileResponse(save_path)

@app.get("/")
def home():
    return {"状态": "服务运行成功 ✅", "AI模型已加载": AI_READY}